package com.demo.maven2;

public class Sweets extends Gifts {
	public Sweets(int w,int p){
		weight.add(w);
	}

}
